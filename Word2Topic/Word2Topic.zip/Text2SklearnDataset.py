import os

datalines=open("D:/publications/preparing/00blockchain/data/policydatalines.txt", 'r')

c_list=datalines.readlines()

print(len(c_list))